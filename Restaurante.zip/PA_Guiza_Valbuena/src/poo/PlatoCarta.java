package poo;


import java.util.ArrayList;
import java.util.List;


/**
 * 
 */
public class PlatoCarta extends Plato {
  private String dia;

  /**
   * Método Constructor
 * @param codigopl
 * @param nombrepl
 * @param precio
 * @param tipo
 * @param dia
 */
public PlatoCarta (int codigopl, String nombrepl, double precio, String tipo, String dia) {
    super(codigopl, nombrepl, precio, tipo);
    this.dia=dia;
  }

  /**
 * @return
 */
public String getDia(){
    return dia;
  }

  /**
 * @param dia
 */
public void setDia(String dia){
    this.dia=dia;
  }

  /**
 * @param indice
 * @param precio
 * @return
 */
public double calcularPrecio(int indice, double precio) {
    return 0;
  }

  /**
 *Método Calcular Precio
 */
public double calcularPrecio(double precio)
  { 
    precio=precio*1.29;
     setPrecio(precio); 
    return precio;
  }
  
  
  /**
 *Metodo to String
 */
@Override
  public String toString(){
    return super.toString()+"dia="+dia;
  }
}