package poo;

import java.io.Serializable;

/**
 * 
 */
public class Ingrediente implements Serializable {
  private int codigo;
  private String nombrein;
  private double precioUnitario;
  private String descripcionUnidad;
  private int inventario;
  private int minimoReq;

  /**
   * Método constructor 
 * @param codigo
 * @param nombrein
 * @param precioUnitario
 * @param descripcionUnidad
 * @param inventario
 * @param minimoReq
 */
public Ingrediente (int codigo, String nombrein, double precioUnitario, String descripcionUnidad, int inventario, int minimoReq)
  {
    this.codigo=codigo;
    this.nombrein=nombrein;
    this.precioUnitario=precioUnitario;
    this.descripcionUnidad=descripcionUnidad;
    this.inventario=inventario;
    this.minimoReq=minimoReq;  
  }

  /**
 * @return
 */
public int getCodigo() {
    return codigo;
  }

  /**
 * @param codigo
 */
public void setCodigo(int codigo) {
    this.codigo = codigo;
  }

  /**
 * @return
 */
public String getNombrein() {
    return nombrein;
  }

  /**
 * @param nombrein
 */
public void setNombrein(String nombrein) {
    this.nombrein = nombrein;
  }

  /**
 * @return
 */
public double getPrecioUnitario() {
    return precioUnitario;
  }

  /**
 * @param precioUnitario
 */
public void setPrecioUnitario(double precioUnitario)
  {
    this.precioUnitario = precioUnitario;
  }

  /**
 * @return
 */
public int getInventario () {
    return inventario;
  }

  /**
 * @param inventario
 */
public void setInventario(int inventario) {
    this.inventario=inventario;
  }

  /**
 * @return
 */
public int getMinimoReq() {
    return minimoReq;
  }

  /**
 * @param minimoReq
 */
public void setMinimoReq(int minimoReq) {
    this.minimoReq=minimoReq;
  }

  /**
 *Método to String
 */
@Override
  public String toString() {
    return "Ingrediente [codigo=" + codigo + ", nombrein=" + nombrein + ", precioUnitario=" + precioUnitario + ", descripcionUnidad=" + descripcionUnidad + ", inventario=" + inventario + ", minimoReq=" + minimoReq + "]";
  }
}