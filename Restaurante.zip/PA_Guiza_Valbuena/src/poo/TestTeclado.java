package poo;

import java.util.Scanner;
//import java.awt.MenuBar;
import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.Serializable;
import java.io.FileOutputStream;
import java.io.ObjectOutputStream;
import java.io.ObjectInputStream;
import java.time.LocalDate;
import java.util.Locale;
import java.time.DayOfWeek;



/**
 * 
 */
public class TestTeclado implements Serializable  {    
    
     private static IRestaurante restaurante = new Restaurante();
    
    /**
     * Main 
     * @param args
     */
    public static void main(String[] args)
    {

        String nomarchivo= "a";
        String nomarchivo2 = "a";
        int contadorpedidos=0;
        Scanner s = new Scanner(System.in);
        int opcion = 1000;
        while (opcion!=10) {
        System.out.println("RESTAURANTE JAVEREST");
        System.out.println("opcion 1: agregar ingredientes al sistema  ");
        System.out.println("opción 2: agregar platos al sistema  ");
        System.out.println("opción 3: mostrar el menú del restaurante");
        System.out.println("opción 4: agregar una orden al sistema   ");
        System.out.println("opción 5: mostrar los tres platos más solicitados  ");
        System.out.println("opción 6: mostrar los tres platos más rentables");
        System.out.println("opción 7: totalizar las órdenes de un día");
        System.out.println("opción 8: guardar el sistema (serializar)");
        System.out.println("opción 9: cargar el sistema (deserializar)");
        System.out.println("opción 10: Salir");

            System.out.println("opcion: ");
              opcion= s.nextInt();

            switch(opcion) {

                case 1: System.out.println("Nombre archivo ingredientes");
                    
                    nomarchivo = s.next();
                    
                    ManejadorArchivos me = new ManejadorArchivos();
                    restaurante= me.leerdatosing(nomarchivo);

                    System.out.println(restaurante.toString());
                        break;

                case 2:  System.out.println("Nombre archivo agregar-plato");
                    nomarchivo2 = s.next();
                    
                    ManejadorArchivos me2 = new ManejadorArchivos();

                    restaurante = me2.leerdatospl(nomarchivo2, nomarchivo);
                    
                    System.out.println(restaurante.toString());
                        break;

                case 3: System.out.println("MENU DEL RESTAURANTE: lista de platos ofrecidos: ");

                       System.out.println("código----nombre---tipo---día---precio: ");

                    try {
                        for (int i=0; i<restaurante.getPlatos().size();i++)
                            {
                                Plato plato = restaurante.getPlatos().get(i);

                                if (plato instanceof PlatoCarta) {
                                    PlatoCarta platocarta = (PlatoCarta)plato;
                                    System.out.println("Código: " + plato.getCodigopl() + ", Nombre: " + plato.getNombrepl() + ", Tipo: " + plato.getTipo() + ", dia: "+ platocarta.getDia() + ", Precio: " + restaurante.calcularPrecio(i));
                                    }
                                else if (plato instanceof PlatoDiario){
                                    System.out.println("Código: " + plato.getCodigopl() + ", Nombre: " + plato.getNombrepl() + ", Tipo: " + plato.getTipo() + ", Precio: " + restaurante.calcularPrecio(i));

                                }
                            }
                    }
                    catch (ResExc e) {
                        System.out.println("Error: " + e);
                    }
                        break;

             case 4: 
                    try {
                        contadorpedidos=contadorpedidos+1000;
                        System.out.println("---- AGREGAR ORDEN: "+ contadorpedidos);
                        System.out.println("---- ¿Cuantos tipos de platos van en la orden?: ");
                        int cantidadplatos=s.nextInt();

                        System.out.println("---- Ingrese el año del pedido: ");
                        String año =s.next();

                        System.out.println("---- Ingrese el mes del pedido: ");
                        String mes =s.next();

                        System.out.println("---- Ingrese el dia del pedido: ");
                        String dia =s.next();

                        Utils utils = new Utils(Integer.parseInt(año), Integer.parseInt(mes), Integer.parseInt(dia));

                        LocalDate fecha = utils.getFecha();

                        String diasem= utils.DiaPlato(fecha);

                        int contador=cantidadplatos;
                        int contadorlista=0;
                        int [] codigos = new int[cantidadplatos];
                        int []cantidades= new int[cantidadplatos];

                        double valor=0;

                        while (contador>0){
                            System.out.println("Indique para cada tipo de plato: código cantidad(de unidades/porciones");
                            int codigo=s.nextInt();
                            codigos[contadorlista]=codigo;

                            int cantidad=s.nextInt();
                            cantidades[contadorlista]=cantidad;
                            contadorlista++;

                            //falta separar
                            valor =restaurante.agregarOrden(contadorpedidos, cantidadplatos, fecha, diasem, contador, codigo, cantidad, valor);
                            contador--;
                        }

                        restaurante.verificarOrden(codigos,cantidades);


                        for (int i=0; i<contadorlista; i++)
                            {
                               restaurante.agregarOrdenpl(codigos[i], cantidades[i]);
                            } 

                        for (int i=0; i<restaurante.getOrdenes().size();i++)
                            {
                                System.out.println(restaurante.getOrdenes().get(i).toString());
                            }
                    } catch (UtilExc e) {
                        System.out.println("Error en la fecha"+ e);
                    } catch (ResExc e) {
                        System.out.println("Error en la orden "+ e);
                    } catch (OrdenExc e){
                        System.out.println("Error en la orden "+ e);
                    }
                    
                        break;   


                case 5: System.out.println("---- PLATOS MÁS SOLICITADOS: ");
                    System.out.println(" codigo      nombre      tipo     solicitudes");
                    String solicitudes = restaurante.platosmasSolicitados();
                    System.out.println(solicitudes);

                        break;

                case 6: System.out.println("---- PLATOS MÁS RENTABLES");

                    System.out.println(" codigo      nombre      dia     solicitudes");
                    String rentables = restaurante.platosmasRentables();

                    System.out.println(rentables);

                        break;

                case 7:
                    try {
                        System.out.println("---- TOTAL DE VENTAS DE UN DIA ------");

                        System.out.println("---- Indique una fecha en formato año/mes/dia: ");

                        System.out.println("---- Ingrese el año del pedido: ");
                        String añov =s.next();

                        System.out.println("---- Ingrese el mes del pedido: ");
                        String mesv =s.next();

                        System.out.println("---- Ingrese el dia del pedido: ");
                        String diav =s.next();

                        Utils utilsv = new Utils(Integer.parseInt(añov), Integer.parseInt(mesv), Integer.parseInt(diav));

                        LocalDate fechav = utilsv.getFecha();

                        String totalv =restaurante.totalVentas(fechav);
                        System.out.println(" codigo            valor");
                        System.out.println(totalv);
                        
                    } catch (UtilExc e) {
                        System.out.println("Error en la fecha"+ e);
                    } catch (ResExc e){
                        System.out.println("Error en la orden "+ e);
                    }
                        
    
                        break;

                    case 8: System.out.println("Como vas a llamar el archivo . txt: ");
                    String nomarchivos = s.next();
                    ManejadorArchivos me3 = new ManejadorArchivos();
                    
                    try {
                        me3.crear(nomarchivos);
                        me3.salvarAArchivo(nomarchivos, restaurante);
                    }
                    catch (IOException e)
                          {
                            System.out.println("El archivo no existe: " + e);
                          } catch (Exception e)
                          {
                            System.out.println("Ocurrió un error: " + e);
                          }
                        break;

                case 9: System.out.println("Nombre del archivo a deserializar . txt: ");
                    String nomarchivos1 = s.next();
                    ManejadorArchivos me4 = new ManejadorArchivos();
                        restaurante = me4.cargarDeArchivo(nomarchivos1);
                        System.out.println(restaurante.toString());
   


                        break;
                    
                    
                }

            }
        }   
}
    