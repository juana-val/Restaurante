
package poo;


import java.util.ArrayList;
import java.util.List;
import java.time.LocalDate;
import java.util.Locale;
import java.time.DayOfWeek;
import java.io.Serializable;

/**
 * 
 */
public interface IRestaurante extends Serializable  {

  /**
 * @return
 */
public List<Ingrediente> getIngredientes();
  /**
 * @param ingredientes
 */
public void setIngredientes(List<Ingrediente> ingredientes);
  /**
 * @param platos
 */
public void setPlatos(List<Plato> platos);
  /**
 * @return
 */
public List<Plato> getPlatos();
  /**
 * @return
 */
public List<Orden> getOrdenes();
  /**
 * @param ordenes
 */
public void setOrdenes(List<Orden> ordenes);

  /**
 * @param codigo
 * @param nombrein
 * @param precioUnitario
 * @param descripcionUnidad
 * @param inventario
 * @param minimoReq
 * @throws ResExc
 */
public void nuevoIngrediente (int codigo, String nombrein, double precioUnitario, String descripcionUnidad, int inventario, int minimoReq) throws ResExc;

  /**
 * @param nombrein
 * @return
 */
public Boolean buscarIngredientes(String nombrein);

  /**
 * @param nombrepl
 * @return
 */
public Plato buscarPlatos(String nombrepl);

  /**
 * @param codigopl
 * @param nombrepl
 * @param precio
 * @param tipo
 * @param dia
 * @throws ResExc
 */
public void nuevoPlato(int codigopl, String nombrepl, double precio, String tipo, String dia) throws ResExc;

  /**
 * @param nombrepl
 * @param codigo
 * @param cantidad
 * @param indice
 * @throws ResExc
 * @throws PlatoExc
 */
public void nuevoingPlato (String nombrepl, int codigo, int cantidad, int indice) throws ResExc, PlatoExc;

  /**
 * @param codigopl
 * @return
 */
public double buscarIngredientepl (int codigopl);

  /**
 * @param indice
 * @return
 * @throws ResExc
 */
public double calcularPrecio(int indice) throws ResExc;

  /**
 * @param contadorpedidos
 * @param cantidadplatos
 * @param fecha
 * @param dia
 * @param contador
 * @param codigo
 * @param cantidad
 * @param valor
 * @return
 * @throws ResExc
 */
public double agregarOrden(int contadorpedidos,int cantidadplatos,LocalDate fecha, String dia,int contador, int codigo,int cantidad, double valor) throws ResExc;

  /**
 * @param codigoor
 * @param cantidador
 * @throws ResExc
 * @throws OrdenExc
 */
public void agregarOrdenpl(int codigoor, int cantidador) throws ResExc, OrdenExc;

  /**
 * @param codigos
 * @param cantidades
 * @throws ResExc
 */
public void verificarOrden(int []codigos, int []cantidades) throws ResExc;

  /**
 * @return
 */
public String platosmasSolicitados();
  
  /**
 * @return
 */
public String platosmasRentables();

  /**
 * @param fechav
 * @return
 * @throws ResExc
 */
public String totalVentas(LocalDate fechav) throws ResExc;
}