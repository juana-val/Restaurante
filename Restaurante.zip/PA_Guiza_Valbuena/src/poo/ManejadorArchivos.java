
package poo;

///

import java.util.Scanner;
import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.Serializable;
import java.io.FileOutputStream;
import java.io.ObjectOutputStream;
import java.io.FileReader;
import java.io.ObjectInputStream;
import java.io.FileWriter;
import java.io.PrintWriter;


/**
 * 
 */
public class ManejadorArchivos implements Serializable {

    private String nombre;

  /**
   * Leer datos del archivo .txt
 * @param nomarchivo
 * @return
 */
public IRestaurante leerdatosing(String nomarchivo) {

      IRestaurante temp = new Restaurante();

      try {
          InputStreamReader archivo = new InputStreamReader(new FileInputStream(nomarchivo));

          BufferedReader fa = new BufferedReader(archivo);

          String cad ="a";
// ingredientes
          cad = fa.readLine();
         cad = fa.readLine(); // primer ing
          
          while (!cad.equalsIgnoreCase("0")) {
              String[]listadatos=cad.split("\\*");

              
              String codigo1=listadatos[0];
              String nombrein=listadatos[1];  
              String precioUnitario1=listadatos[2];
              String descripcionUnidad=listadatos[3];
              String inventario1=listadatos[4];  
              String minimoReq1=listadatos[5];

              int codigo=Integer.parseInt(codigo1);
              
              double precioUnitario=Double.parseDouble(precioUnitario1);
              int inventario=Integer.parseInt(inventario1);
              int minimoReq=Integer.parseInt(minimoReq1);
              
              temp.nuevoIngrediente(codigo, nombrein, precioUnitario, descripcionUnidad, inventario, minimoReq); 
              cad = fa.readLine(); // primer ing
          }
            //fa.close();          
      } catch (IOException e) {
          System.out.println("Un problema en el archivo" + e);
          e.printStackTrace();
      } catch (ResExc e) {
          System.out.println("problema en el ingrediente" + e);
      }
      
      return temp;

  }


    /**
     * Leer datos del archivo.txt 
     * @param nomarchivo2
     * @param nomarchivo
     * @return
     */
    public IRestaurante leerdatospl(String nomarchivo2, String nomarchivo)  {

     IRestaurante temp = new Restaurante();
    IRestaurante temp1 = leerdatosing(nomarchivo);;
        
        try {

            InputStreamReader archivo2 = new InputStreamReader(new FileInputStream(nomarchivo2));

                    BufferedReader fa2 = new BufferedReader(archivo2);

                    String cad2 ="a";

              cad2 = fa2.readLine(); // #Plato

              int indice=-1;

                while (!cad2.equalsIgnoreCase("#FIN")) {

                              cad2 = fa2.readLine(); // lines de contexto

                              cad2 = fa2.readLine(); 

                              String[]listadatos2=cad2.split("\\*");
                              String codigopl2=listadatos2[0];
                              String nombrepl=listadatos2[1];  
                              String tipo=listadatos2[2];
                              String dia ="a";
                            if (tipo.equalsIgnoreCase("CARTA"))
                            {
                                dia=listadatos2[3];
                            }
                              int codigopl=Integer.parseInt(codigopl2);

                             temp.nuevoPlato(codigopl, nombrepl, 0 , tipo, dia);
                                indice++;

                              //temporal

                             cad2 = fa2.readLine();
                             cad2 = fa2.readLine(); 

                            while (!cad2.equalsIgnoreCase("0")) {

                            String[]listadatos3=cad2.split("[\\s]+");

                            String codigoplin2=listadatos3[0];            
                            String cantidad2=listadatos3[1];

                            int  codigoplin=Integer.parseInt(codigoplin2);
                            int cantidad=Integer.parseInt(cantidad2);
                                
                            temp.nuevoingPlato(nombrepl, codigoplin, cantidad, indice);

                              cad2 = fa2.readLine();
                       }
                         cad2 = fa2.readLine();
                      //fa2.close();
                }

            } catch (IOException e) {

                  System.out.println("Un problema en el archivo" + e);
                  e.printStackTrace();
              } catch (ResExc e) {
                  System.out.println("Un problema en el plato" + e);
              } catch (PlatoExc e) {
                    System.out.println("Un problema en el plato" + e);
              }

        temp.setIngredientes(temp1.getIngredientes());

        return temp;   
    }

          /**
           * Crear un archivo de texto.txt
     * @param nombreArchivo
     * @throws IOException
     */
    public void crear(String nombreArchivo) throws IOException
      {
        this.nombre = nombreArchivo;
        ObjectOutputStream archivo = new ObjectOutputStream(new FileOutputStream(this.nombre));
        archivo.close(); // Cierra el ObjectOutputStream después de usarlo
      }
   
  
      /**
       *  serializar
     * @param nomarchivo
     * @param res
     */
    public void salvarAArchivo(String nomarchivo, IRestaurante res)
      {
        try {
          FileOutputStream fileOut = new FileOutputStream(nomarchivo);
          ObjectOutputStream out = new ObjectOutputStream(fileOut);
          out.writeObject(res);
          out.close();
        }
          catch (Exception e)
          {
            System.out.println("Error al escribir el archivo: " + e.getMessage());
          }
      }
  
      /**
       *  deserializar
     * @param nomarchivo
     * @return
     */
    public IRestaurante cargarDeArchivo (String nomarchivo) 
      {
        IRestaurante res = null;
        try {
          FileInputStream fileIn = new FileInputStream(nomarchivo);
          ObjectInputStream in = new ObjectInputStream(fileIn);
          res = (IRestaurante) in.readObject();
         in.close();
        }
          catch (IOException e)
          {
            System.out.println("El archivo no existe: " + e);
          } catch (Exception e)
          {
            System.out.println("Ocurrió un error: " + e);
          }
        return res;
      
    }

}