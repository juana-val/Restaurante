package poo;

public class ResExc extends Exception {

private String detalle;

  /**
   * @param detalle
   */
  public ResExc(String detalle) {
    this.detalle = detalle;
  }

  @Override
  public String toString() {
    return "ResExc [detalle=" + detalle + "]";
  }

}