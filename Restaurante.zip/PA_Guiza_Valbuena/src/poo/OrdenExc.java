package poo;


public class OrdenExc extends Exception {

private String detalle;

  /**
   * @param detalle
   */
  public OrdenExc(String detalle) {
    this.detalle = detalle;
  }

  @Override
  public String toString() {
    return "OrdenExc [detalle=" + detalle + "]";
  }

}