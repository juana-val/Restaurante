package poo;

import java.io.Serializable;

/**
 * 
 */
public class IngredientePlato implements Serializable {
  private int cantidad;
  private int codigo;

  /**
   * Método Constructor
 * @param cantidad
 * @param codigo
 */
public IngredientePlato(int cantidad, int codigo) {
    this.cantidad=cantidad;
    this.codigo=codigo;
  }

/**
 * @return
 */
public int getCantidad() {
	return cantidad;
}

/**
 * @param cantidad
 */
public void setCantidad(int cantidad) {
	this.cantidad = cantidad;
}

/**
 * @return
 */
public int getCodigo() {
	return codigo;
}

/**
 * @param codigo
 */
public void setCodigo(int codigo) {
	this.codigo =codigo;
}

  /**
 *Método to String
 */
@Override
  public String toString() {
    return "IngredientePlato [cantidad=" + cantidad + ", codigo=" + codigo + "]";
  }
  
}
