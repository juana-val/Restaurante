package poo;



import java.util.ArrayList;
import java.util.List;
import java.time.LocalDate;
import java.util.Locale;
import java.time.DayOfWeek;
 import java.io.Serializable;

/**
 * 
 */
public class Orden implements Serializable {
  private int codigo;
  private double valor;
  private int cantidad;
  private LocalDate fecha;
  private List<OrdenPlato> ordenespl;

  /**
   * Método constructor
 * @param codigo
 * @param cantidad
 * @param fecha
 * @param valor
 */
public Orden (int codigo,int cantidad, LocalDate fecha, double valor)
  {
    this.codigo=codigo;
    this.valor=valor;
    this.cantidad=cantidad;
    this.fecha=fecha;
    this.ordenespl=new ArrayList<OrdenPlato>();
  }

  /**
 * @return
 */
public int getCodigo() {
    return codigo;
  }

  /**
 * @param codigo
 */
public void setCodigo(int codigo) {
    this.codigo = codigo;
  }

  /**
 * @return
 */
public double getValor() {
    return valor;
  }

  /**
 * @param valor
 */
public void setValor(int valor) {
    this.valor = valor;
  }

  /**
 * @return
 */
public int getCantidad() {
    return cantidad;
  }

  /**
 * @param cantidad
 */
public void setCantidad(int cantidad) {
    this.cantidad = cantidad;
  }

  /**
 * @return
 */
public LocalDate getFecha() {
    return fecha;
  }

  /**
 * @param fecha
 */
public void setFecha(LocalDate fecha) {
    this.fecha = fecha;
  }

  /**
 * @return
 */
public List<OrdenPlato> getOrdenes() {
    return ordenespl;
  }

  /**
 * @param ordenespl
 */
public void setOrdenes(List<OrdenPlato> ordenespl) {
    this.ordenespl = ordenespl;
  }

  /**
   * Buscar orden según el código
 * @param codigoor
 * @return
 */
public OrdenPlato buscarOrden(int codigoor) {
    
    for (OrdenPlato orden : ordenespl) {
      if (orden.getCodigopl() == codigoor) {
        return orden;
      }
    }
    return null;
  }
// cantidador --- platos con mismo cod
  /**
   * Agregar Orden de plato
 * @param codigoor
 * @param cantidador
 * @param precio
 * @throws OrdenExc
 */
public void agregarOrdenpl(int codigoor, int cantidador, double precio) throws OrdenExc{
    OrdenPlato existe = buscarOrden(codigoor);
    if (existe ==null) {
      OrdenPlato ordenpl = new OrdenPlato(cantidador, codigoor, precio);
      ordenespl.add(ordenpl);
    } 
    else {
      throw new OrdenExc("El plato ya existe en la orden");
    }
    
  }
  /**
 *Método to String
 */
@Override
  public String toString() {
    return "Orden [codigo=" + codigo + ", valor=" + valor + ", cantidad=" + cantidad + "," + fecha + "Lista Platos=" + ordenespl + "]";
  }

  
}