package poo;


import java.time.LocalDate;
import java.util.Locale;
import java.time.DayOfWeek;
import java.time.format.TextStyle;


/**
 * 
 */
public class Utils {

  LocalDate fecha;

  /**
   * metodo constructor
 * @param año
 * @param mes
 * @param dia
 * @throws UtilExc
 */
public Utils(int año, int mes, int dia) throws UtilExc {
    if((mes<=12 && mes>=1) && (dia<=31 && dia>=1) || (mes==2 && dia<=29)){
    fecha = LocalDate.of(año, mes, dia);
    }
    else {
      throw new UtilExc("Fecha no valida");
    }
  }

  /**
   * Metodo que retorna el día de la semana según la fecha dada
 * @return
 */
public LocalDate getFecha() {
    return fecha;
  }

    public String DiaPlato(LocalDate date) {
        DayOfWeek dayOfWeek = date.getDayOfWeek();
      String diasem = dayOfWeek.getDisplayName(TextStyle.FULL, Locale.US);

      if (diasem.equals("Monday"))
      {
        return "lu";
      }
      if (diasem.equals("Tuesday"))
        {
          return "ma";
        }
      if (diasem.equals("Wednesday"))
        {
          return "mi";
        }
      if (diasem.equals("Thursday"))
        {
          return "ju";
        }
      if (diasem.equals("Friday"))
        {
          return "vi";
        }
      if (diasem.equals("Saturday"))
        {
          return "sa";
        }
      if (diasem.equals("Sunday"))
        {
          return "do";
        }

      return diasem;
    }
  
}