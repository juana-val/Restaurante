package poo;


public class UtilExc extends Exception {

private String detalle;

  /**
   * @param detalle
   */
  public UtilExc(String detalle) {
    this.detalle = detalle;
  }

  @Override
  public String toString() {
    return "UtilExc [detalle=" + detalle + "]";
  }

}