package poo;

import java.io.Serializable;

public class OrdenPlato implements Serializable {

  private int cantidad;
  private int codigopl;
  private double preciopl;

  public OrdenPlato(int cantidad, int codigopl, double preciopl){

    this.cantidad=cantidad;
    this.codigopl=codigopl;
    this.preciopl=preciopl;
  }

  public int getCantidad(){
    return cantidad;
  }

  public void setCantidad(int cantidad){
    this.cantidad=cantidad;
  }

  public int getCodigopl(){
    return codigopl;
  }

  public void setCodigopl(int codigopl) {
    this.codigopl=codigopl;
  }

  public double getPreciopl(){
    return preciopl;
  }

  public void setPreciopl(double preciopl){
    this.preciopl=preciopl;
  }

  @Override
  public String toString() {

    return "OrdenPlato [cantidad=" + cantidad + ", codigopl=" + codigopl + ", preciopl=" + preciopl + "]";
  }
}