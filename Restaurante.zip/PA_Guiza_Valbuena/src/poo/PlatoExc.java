package poo;


public class PlatoExc extends Exception {

private String detalle;

  /**
   * @param detalle
   */
  public PlatoExc(String detalle) {
    this.detalle = detalle;
  }

  @Override
  public String toString() {
    return "PlatoExc [detalle=" + detalle + "]";
  }

}