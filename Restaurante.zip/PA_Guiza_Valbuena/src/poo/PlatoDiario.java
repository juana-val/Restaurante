package poo;


import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;


/**
 * 
 */
public class PlatoDiario extends Plato {


  /**
   * M[etodo constructor
 * @param codigopl
 * @param nombrepl
 * @param precio
 * @param tipo
 */
public PlatoDiario(int codigopl, String nombrepl, double precio, String tipo) {
    super(codigopl, nombrepl, precio, tipo);
  }
  

  /**
 *metodo calcular precio
 */
public double calcularPrecio(double precio)
  { 
    precio=precio*1.19;
     setPrecio(precio); 
    return precio;
  }

  
/**
 *metodo to String
 */
@Override
  public String toString()
  {
    return super.toString();
  }
}