package poo;


import java.util.ArrayList;
import java.util.List;
import java.io.Serializable;

public abstract class Plato implements Serializable{
  private int codigopl;
  private String nombrepl;
  private double precio;
  private String tipo;
  protected List<IngredientePlato> ingredientespl;
  
  public Plato (int codigopl, String nombrepl, double precio, String tipo) {
    this.codigopl=codigopl;
    this.nombrepl=nombrepl;
    this.precio=precio;
    this.tipo=tipo;
    this.ingredientespl=new ArrayList<IngredientePlato>();
  }

  public int getCodigopl() {
    return codigopl;
  }

  public void setCodigopl(int codigopl) {
    this.codigopl = codigopl;
  }

  public String getNombrepl() {
    return nombrepl;
  }

  public void setNombrepl(String nombrepl) {
    this.nombrepl = nombrepl;
  }

  public double getPrecio() {
    return precio;
  }

  public void setPrecio(double precio) {
    this.precio = precio;
  }

  public String getTipo() {
    return tipo;
  }

  public void setTipo(String tipo) {
    this.tipo = tipo;
  }

  public List<IngredientePlato> getIngredientespl() {
    return ingredientespl;
  }

  public void setIngredientespl(List<IngredientePlato> ingredientespl) {
    this.ingredientespl = ingredientespl;
  }

  public Boolean buscarIngredientepl(int codigo) {
    for (IngredientePlato c:ingredientespl) {
      if (c.getCodigo()==codigo){
         return true;
      }
    }
   return false;
  }

  public void nuevoingPlato (int codigo, int cantidad) throws PlatoExc {
    Boolean existe = buscarIngredientepl(codigo);
   IngredientePlato PlatoIng1 = new IngredientePlato(cantidad, codigo);
    if (!existe){
        getIngredientespl().add(PlatoIng1);
      }
    else {
      throw new PlatoExc("El ingrediente ya existe en el plato");
    }
  }


  @Override
  public String toString() {
    return "Plato [codigopl=" + codigopl + ", nombrepl=" + nombrepl + ", precio=" + precio + ", tipo=" + tipo + "IngredientesPlato"+ ingredientespl + "]";
  }

  public abstract double calcularPrecio(double precio);
  
}