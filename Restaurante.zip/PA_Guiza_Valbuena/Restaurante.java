package poo;


import java.util.ArrayList;
import java.util.List;
import java.time.LocalDate;
import java.util.Locale;
import java.io.Serializable;
import java.time.DayOfWeek;

/**
 * 
 */
public class Restaurante implements IRestaurante, Serializable  {
  private List<Ingrediente> ingredientes; 
  private List<Plato> platos;
  private List<Orden> ordenes;

  /**
 * M[etodo constructor
 */
public Restaurante () {
    ingredientes =new ArrayList<Ingrediente>();
    platos=new ArrayList<Plato>();
    ordenes=new ArrayList<Orden>();
  }

  /**
 *
 */
public List<Ingrediente> getIngredientes() {
    return ingredientes;
  }

  /**
 *
 */
public List<Plato> getPlatos() {
    return platos;
  }

  /**
 *
 */
public void setIngredientes(List<Ingrediente> ingredientes) {
    this.ingredientes = ingredientes;
  }

  /**
 *
 */
public void setPlatos(List<Plato> platos) {
    this.platos = platos;
  }

  /**
 *
 */
public List<Orden> getOrdenes() {
    return ordenes;
  }

  /**
 *
 */
public void setOrdenes(List<Orden> ordenes) {

    this.ordenes = ordenes;
  }
  

  /**
 *metodo to String
 */
@Override
  public String toString() {
    return "Restaurante [ingredientes=" + ingredientes + ", platos=" + platos + "]";
  }  

  // buscar ingrediente//
  /**
 *Metodo buscar ingredientes en la lista segun su nombre
 */
public Boolean buscarIngredientes(String nombrein) {
    for (Ingrediente c:ingredientes) {
      if (c.getNombrein().equals(nombrein)){
         return true;
      }
    }
   return false;
  }

  //////añadir ingrediente
  /**
 *Añadir nuevo ingrediente a la lista
 */
public void nuevoIngrediente (int codigo, String nombrein, double precioUnitario, String descripcionUnidad, int inventario, int minimoReq) throws ResExc {
    Boolean existe = buscarIngredientes(nombrein);
    Ingrediente newIngrediente = new Ingrediente (codigo, nombrein, precioUnitario, descripcionUnidad, inventario, minimoReq);
    if (!existe){
        ingredientes.add(newIngrediente);
      }
      else {
        throw new ResExc("El ingrediente ya existe");
      }
    }
  
  // buscar plato
  /**
 *Buscar plato segun su nombre
 */
public Plato buscarPlatos(String nombrepl) {
    for (Plato p:platos) {
      if (p instanceof PlatoCarta)
      {
        PlatoCarta c = (PlatoCarta) p;
        if (c.getNombrepl().equals(nombrepl)){
           return c;
        }
      }
       else if (p instanceof PlatoDiario) {
        PlatoDiario d = (PlatoDiario) p;
        if (d.getNombrepl().equals(nombrepl)){
           return d;
        }
       }
    }
   return null;
  }


/**
 * Añadir nuevo plato segun su tipo a la lista plato
 */
public void nuevoPlato (int codigopl, String nombrepl, double precio, String tipo, String dia) throws ResExc{
   Plato existe =buscarPlatos(nombrepl);
  
  if (existe==null){
    if (tipo.equals("diario")){
      platos.add(new PlatoDiario(codigopl, nombrepl, precio, tipo));
    }
    else{
      platos.add(new PlatoCarta(codigopl, nombrepl, precio, tipo , dia));
    }
  }
  else {
    throw new ResExc("El plato ya existe");
  }

}

  /**
 *Añadir nuevo ingrediente al plato
 */
public void nuevoingPlato(String nombrepl, int codigo, int cantidad, int indice) throws ResExc, PlatoExc {
  Plato existe = buscarPlatos(nombrepl);
  if (existe!=null){ 
      getPlatos().get(indice).nuevoingPlato(codigo, cantidad);
    }
    else {
      throw new ResExc("El plato no existe");
    }
  }
  

    /**
     * Buscar ingrediente en la lista ingredinetes segun su codigo
     */
    public double buscarIngredientepl (int codigopl)
  {
    for (Ingrediente c:ingredientes) {
      if (c.getCodigo()==codigopl){
         return c.getPrecioUnitario();
      }
    }
   return -1;
  }
  

    /**
     *Calcular precio del plato segun los ingredientes y sus cantidades
     */
    public double calcularPrecio(int indice) throws ResExc
    {
      double precio=0;
      double preciofinal=0;
      double existe=-1;

      for(int i=0; i<getPlatos().get(indice).getIngredientespl().size();i++)
        {
            existe= buscarIngredientepl(getPlatos().get(indice).getIngredientespl().get(i).getCodigo());
            if (existe!=-1)
            {
              precio = existe;
              precio = precio * getPlatos().get(indice).getIngredientespl().get(i).getCantidad();
              preciofinal=preciofinal+precio;
            }
        else {
          throw new ResExc("El ingrediente no existe");
        }
      }
preciofinal=getPlatos().get(indice).calcularPrecio(preciofinal);
      
      return preciofinal;
  }


  /**
   * Buscar plato en la lista de platos segun su codigo
 * @param codigo
 * @return
 */
public Plato buscarPlatos2(int codigo) {
    for (Plato p:platos) {
      if (p instanceof PlatoCarta)
      {
        PlatoCarta c = (PlatoCarta) p;
        if (c.getCodigopl() == codigo){
           return c;
        }
      }
       else if (p instanceof PlatoDiario) {
        PlatoDiario d = (PlatoDiario) p;
        if (d.getCodigopl() ==codigo){
           return d;
        }
       }
    }
   return null;
  }

  /**
   * Buscar ingrediente en la lista ingredientes segun su codigo
 * @param codigo
 * @return
 */
public Ingrediente buscarIngredientes2(int codigo) {
    for (Ingrediente c:ingredientes) {
      if (c.getCodigo()==codigo){
         return c;
      }
    }
   return null;
  }
  

  /**
 *Agregar orden al  sistema
 */
public double agregarOrden(int contadorpedidos, int cantidadplatos, LocalDate fecha, String dia, int contador, int codigo, int cantidad, double valor) throws ResExc {

    int indice=0;//-1

    Plato plato = buscarPlatos2(codigo);

    if (plato!=null) {

      if (plato instanceof PlatoCarta)
      {
        PlatoCarta c = (PlatoCarta) plato;
        if (dia.equals(c.getDia()))
        {
          for (int i=0; i<platos.size(); i++) {
            if (platos.get(i).getCodigopl()==codigo)
            {
              indice=i;
                  break;
            }
          }
          valor = valor + (calcularPrecio(indice)*cantidad);
        }
      }

      else if (plato instanceof PlatoDiario) {

        for (int i=0; i<platos.size(); i++) {
          if (platos.get(i).getCodigopl()==codigo)
          {
            indice=i;
              break;
          }
        }

        valor = valor + (calcularPrecio(indice)*cantidad);
      }
      
    }
    else {
      throw new ResExc("El plato no existe");
    }

    if (contador==1)
      {
      Orden nuevaOrden = new Orden(contadorpedidos, cantidadplatos, fecha, valor);
          ordenes.add(nuevaOrden);
      }

    return valor;
    
  }


  /**
 * Verificar que la orden pueda ser realizada segun los ingredientes disponibles en el inventario
 */
public void verificarOrden(int []codigos, int []cantidades) throws ResExc{

    List<Plato> auxpl = new ArrayList<Plato>();
    List<Ingrediente> auxin = new ArrayList<Ingrediente>();
    
    for (int i=0; i<codigos.length; i++){
      Plato plato = buscarPlatos2(codigos[i]);
      if (plato!=null){
        auxpl.add(plato);
      }
    }

    for (Plato p: auxpl) {
      for (int i=0; i<p.getIngredientespl().size(); i++) {
        Ingrediente ing = buscarIngredientes2(p.getIngredientespl().get(i).getCodigo());
        if (ing!=null){
          // buscar ingrediente//

          if (auxin.size()==0) {
            auxin.add(ing);
          }

          Boolean existe=true;
          
            for (Ingrediente c:auxin) {
              if (c.getNombrein().equals(ing.getNombrein())){
                existe=true;
                break;
              } else 
                 existe=false;
            }
          if(!existe) {
            auxin.add(ing);
          }
        }
      }
    }

    for (Plato p: auxpl) {
      int indice=0;

      for (int k=0; k<codigos.length;k++){
        if(p.getCodigopl()==codigos[k]) {
          indice=k;
        }
      }
      
      int conta= cantidades[indice];

      while (conta!=0) {
 
        for (int i=0; i<p.getIngredientespl().size(); i++) {
          for (Ingrediente in: auxin) {
      
            if (p.getIngredientespl().get(i).getCodigo()==in.getCodigo()) {
              in.setInventario(in.getInventario()-p.getIngredientespl().get(i).getCantidad());
            }  
          }
        }
        conta--;
      }
    }

    for (Ingrediente i: auxin) {
      if (i.getInventario()<i.getMinimoReq()) {
        throw new ResExc("El ingrediente no cumple con el minimo requerido de inventario");
      }
    }

    for (Ingrediente aux: auxin){
      for (Ingrediente in:ingredientes) {

        if (aux.getCodigo()==in.getCodigo()) {
          in.setInventario(aux.getInventario());
       }
      }
    }
  }
  
  /**
 * Agregar plato a la orden
 */
public void agregarOrdenpl (int codigoor, int cantidad) throws ResExc, OrdenExc {
  
    double precio=0;
    int indice=0;

    Plato existe = buscarPlatos2(codigoor);
    if (existe!=null){ 
        for (int i=0; i<platos.size(); i++) {
          if (platos.get(i).getCodigopl()==codigoor)
          {
            indice=i;
          }
        }
            precio = calcularPrecio(indice)*cantidad;            
            ordenes.get(ordenes.size()-1).agregarOrdenpl(codigoor, cantidad, precio);         
    } else {
      throw new ResExc("No hay plato");
    }

}

  /**
 *Método para calcular los platos más solicitados en ese dia
 */
public String platosmasSolicitados () {

    String solicitudes = " ";
    int []codigos = new int[platos.size()];
    int []cantidades = new int[platos.size()];
    for (int i=0; i<platos.size(); i++)
      {
        cantidades[i]=0;
      }
    int tam=0;
    
    for (Plato p:platos) {
      for (Orden o:ordenes) {
        for (int i=0; i<o.getOrdenes().size() ;i++) {
          if (o.getOrdenes().get(i).getCodigopl()==p.getCodigopl()) {   
            codigos[tam]=p.getCodigopl();
            cantidades[tam]= cantidades[tam] + o.getOrdenes().get(i).getCantidad();
          }    
        }
      }
      tam++;
    }  
        int n = codigos.length;
        boolean cambio;
        do {
            cambio = false;
            for (int i = 1; i < n; i++) {
                if (cantidades[i - 1] < cantidades[i]) {
                    int temp = cantidades[i - 1];
                  cantidades[i - 1] = cantidades[i];
                    cantidades[i] = temp;
                  
                    int temp2 = codigos[i - 1];
                    codigos[i-1] = codigos[i];
                    codigos[i] = temp2;
                    cambio = true; 
                }
            }
            n--;
        } while (cambio);

    for (int i=0; i<3; i++) {
      for (Plato p:platos) {
        if (p.getCodigopl()==codigos[i]) {
          solicitudes = solicitudes + p.getCodigopl() + "       " + p.getNombrepl() + "      " + p.getTipo() +"         " + cantidades[i] + "\n";
        }
      }
    }
    return solicitudes;
  }

/**
 *Método para calcular los platos más rentables en ese dia
 */
public String platosmasRentables () {

    String rentables = " ";
    double []prentables = new double[platos.size()];
    int []codigo = new int[platos.size()];
    for (int i=0; i<platos.size(); i++)
      {
        prentables[i]=0;
      }
    int tam=0;

    for (Plato p:platos) {
      for (Orden o:ordenes) {
        for (int i=0; i<o.getOrdenes().size() ;i++) {
          if (o.getOrdenes().get(i).getCodigopl()==p.getCodigopl()) {   
            codigo[tam]=p.getCodigopl();
            prentables[tam]= prentables[tam] + o.getOrdenes().get(i).getPreciopl();
          }    
        }
      }
      tam++;
    }  
        int n = codigo.length;
        boolean cambio;
        do {
            cambio = false;
            for (int i = 1; i < n; i++) {
                if (prentables[i - 1] < prentables[i]) {
                    double temp = prentables [i - 1];
                    prentables[i - 1] = prentables[i];
                    prentables[i] = temp;

                    int temp2 = codigo[i - 1];
                    codigo[i-1] = codigo[i];
                    codigo[i] = temp2;
                    cambio = true; 
                }
            }
            n--;
        } while (cambio);

    for (int i=0; i<3; i++) {
      for (Plato p:platos) {
        if (p.getCodigopl()==codigo[i]) {
          if (p instanceof PlatoCarta){
            PlatoCarta c = (PlatoCarta) p;
          rentables = rentables + p.getCodigopl() + "       " + p.getNombrepl() + "      " + c.getDia() +"         " + prentables[i] + "\n";
        }else {
            if (p instanceof PlatoDiario){
              PlatoDiario d = (PlatoDiario) p;
              rentables = rentables + p.getCodigopl() + "       " + p.getNombrepl() + "      " + "       " +"         " + prentables[i] + "\n";
            }
            }
          }  
      }
    }
  return rentables;
  }

  /**
 *Calcular el total de ventas de ese dia
 */
public String totalVentas(LocalDate fechav) throws ResExc {
    
    String ventas = " ";
    double []ventasar = new double[ordenes.size()];
    int []codigo = new int[ordenes.size()];
    for (int i=0; i<ordenes.size(); i++)
      {
        ventasar[i]=0;
      }
    int tam=0;

      for (Orden o:ordenes) {
        if (o.getFecha().isEqual(fechav)) {
          for (int i=0; i<o.getOrdenes().size() ;i++) { 
            ventasar[tam]= ventasar[tam] + o.getOrdenes().get(i).getPreciopl();    
            codigo[tam]=o.getCodigo();
          }
        }
        tam++;
      }

    if (ventasar[0]==0) {
      throw new ResExc("No hubo ventas esa fecha");
    }
 
    double total=0.0;
       for(int i=0; i<codigo.length; i++) {
         total=total + ventasar[i];
         ventas = ventas + codigo[i] + "       " + ventasar[i] + "\n";
       }

    ventas= ventas+ "Total: " + total;

    return ventas;
  }
  
}
